import { inject, Injectable, effect, computed } from '@angular/core';
import { ConfigStoreService } from './config-store.service';
import { TranslationService } from './translation.service';
import { LanguageSignalService } from './language-signal.service';
import { ConfigSchema } from './config.schema';

@Injectable({ providedIn: 'root' })
export class DynamicTranslationService {
    private configStore = inject(ConfigStoreService);
    private translationService = inject(TranslationService);
    private langSignal = inject(LanguageSignalService);

    private config = computed(() => this.configStore.config());
    private lang = computed(() => this.langSignal.currentLang());

    constructor() {
        effect(() => {
            const lang = this.lang();
            if (lang === 'es') return; // No traducir si es español

            const conf = this.config();
            // Hero
            this.translationService.translateText('hero.headline', conf.section_hero.headline.text, lang);
            this.translationService.translateText('hero.subheadline', conf.section_hero.subheadline.text, lang);
            conf.section_hero.buttons.forEach((btn, i) => {
                this.translationService.translateText(`hero.button.${i}`, btn.text, lang);
            });

            // Header
            this.translationService.translateText('header.title', conf.header.title, lang);
            for (const key in conf.header.menu) {
                const typedKey = key as keyof ConfigSchema['header']['menu'];
                this.translationService.translateText(`header.menu.${typedKey}`, conf.header.menu[typedKey], lang);
            }
        });
    }

    // Métodos públicos de acceso
    getHeroHeadline(): string {
        return this.lang() === 'es'
            ? this.config().section_hero.headline.text
            : this.translationService.getTranslatedText('hero.headline') ?? '';
    }

    getHeroSubheadline(): string {
        return this.lang() === 'es'
            ? this.config().section_hero.subheadline.text
            : this.translationService.getTranslatedText('hero.subheadline') ?? '';
    }

    getHeroButton(index: number): string {
        return this.lang() === 'es'
            ? this.config().section_hero.buttons[index]?.text ?? ''
            : this.translationService.getTranslatedText(`hero.button.${index}`) ?? '';
    }

    getHeaderTitle(): string {
        return this.lang() === 'es'
            ? this.config().header.title
            : this.translationService.getTranslatedText('header.title') ?? '';
    }

    getHeaderMenuItem(key: keyof ConfigSchema['header']['menu']): string {
        return this.lang() === 'es'
            ? this.config().header.menu[key]
            : this.translationService.getTranslatedText(`header.menu.${key}`) ?? '';
    }
}
