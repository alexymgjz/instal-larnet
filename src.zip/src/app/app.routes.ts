import {Routes} from '@angular/router';


export const routes: Routes = [ // Asegúrate de exportar 'routes'
];
